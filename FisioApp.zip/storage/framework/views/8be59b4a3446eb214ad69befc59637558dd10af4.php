<!DOCTYPE html>
<html lang="en">


<!-- add-patient24:06-->

<head>
    <?php echo $__env->make('_part.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('_part.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
    <div class="main-wrapper">
        <!-- HEADER -->
        <?php echo $__env->make('_part.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- SIDEBAR -->
        <?php echo $__env->make('_part.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END SIDEBAR -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Tambah Tindakan</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <form action="<?php echo e(route('tindakan.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Kode Tindakan <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="kode_tindakan" required autocomplete="off" placeholder="Contoh : US 10x" >
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label>Nama Tindakan</label>
                                                <input type="text" class="form-control" name="nama_tindakan" autocomplete="off" placeholder="Harap diawal dengan huruf kapital">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Harga Jual</label>
                                        <input type="form_control" class="form-control" name="harga_jual" autocomplete="off" onkeypress="return event.charCode >= 48 && event.charCode <=57">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Komisi Tindakan</label>
                                        <input class="form-control" type="text" name="komisi_tindakan" autocomplete="off" onkeypress="return event.charCode >= 48 && event.charCode <=57">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Kategori Tindakan<span class="text-danger">*</span></label>
                                        <select class="select" name="kategori_tindakan" required autocomplete="off">
                                            <option>Rendah</option>
                                            <option>Medium</option>
                                            <option>Tinggi</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Status Member</label>
                                        <select class="select" name="status_member" required autocomplete="off">
                                            <option>Ya</option>
                                            <option>Tidak</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Status Aktif</label>
                                        <select class="select" name="status_aktif" required autocomplete="off">
                                            <option>Ya</option>
                                            <option>Tidak</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Keterangan</label>
                                        <input class="form-control" type="text" name="keterangan" autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn">Tambah Tindakan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
     <!-- FOOTER -->
     <?php echo $__env->make('_part.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

<!-- add-patient24:07-->

</html>
<?php /**PATH C:\xampp\htdocs\FisioApp\resources\views/tambah_tindakan.blade.php ENDPATH**/ ?>