<!DOCTYPE html>
<html lang="en">


<!-- profile22:59-->

<head>
    <?php echo $__env->make('_part.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('_part.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
    <div class="main-wrapper">
        <!-- HEADER -->
        <?php echo $__env->make('_part.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- SIDEBAR -->
        <?php echo $__env->make('_part.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END SIDEBAR -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-4 col-3">
                        <h4 class="page-title">Riwayat Pasien</h4>
                    </div>
                    <div class="col-sm-8 col-9 text-right m-b-20">
                        <a href="<?php echo e(route('rekam-medis.create', $pasien->id)); ?>" class="btn btn btn-primary btn-rounded float-right"><i class="fa fa-plus"></i> Tambah Rekam Medis</a>
                    </div>
                </div>
                <div class="card-box profile-header">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="profile-view">
                                <div>
                                    <div class="row">
                                        <div class="col-md-7">
                                            <ul class="personal-info">
                                                <h3 class="user-name m-t-0 mb-0"><?php echo e($pasien->nama); ?></h3></br>
                                                <li>
                                                    <span class="title">No. Registrasi:</span>
                                                    <span class="text"><?php echo e(sprintf('%04d', $pasien->id)); ?></a></span>
                                                </li>
                                                <li>
                                                    <span class="title">Alamat:</span>
                                                    <span class="text"><?php echo e($pasien->alamat); ?></span>
                                                </li>
                                                <li>
                                                    <span class="title">No. Telepon:</span>
                                                    <span class="text"><?php echo e($pasien->no_telp); ?></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="profile-tabs">
                    <ul class="nav nav-tabs nav-tabs-bottom">
                        <li class="nav-item"><a class="nav-link active" href="#rekam-medis" data-toggle="tab">Rekam Medis</a></li>
                        <li class="nav-item"><a class="nav-link" href="#riwayat-pembayaran" data-toggle="tab">Riwayat Pembayaran</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane show active" id="rekam-medis">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table table-border table-striped custom-table datatable mb-0">
                                            <thead>
                                                <tr>
                                                    <th>Tanggal Terapi</th>
                                                    <th>Nama Terapis</th>
                                                    <th>Anamnesa</th>
                                                    <th>Pemeriksaan</th>
                                                    <th>Diagnosa</th>
                                                    <th>Tindakan</th>
                                                    <th class="text-right">Opsi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $rekam_medis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($rm->created_at->format('d/m/Y H:i')); ?></td>
                                                    <td><?php echo e($rm->users->name); ?></td>
                                                    <td><?php echo e($rm->anamnesa); ?></td>
                                                    <td><?php echo e($rm->pemeriksaan); ?></td>
                                                    <td><?php echo e($rm->diagnosa); ?></td>
                                                    <td><?php echo e(implode(', ', $rm->tindakan()->get()->pluck('nama_tindakan')->toArray())); ?></td>
                                                    <td class="text-right">
                                                        <div class="dropdown dropdown-action">
                                                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                <a class="dropdown-item" href="<?php echo e(route('pembayaran.create', $rm->id)); ?>"><i class="fa fa-money m-r-5"></i> Tambah Pembayaran</a>
                                                                <a class="dropdown-item" href="<?php echo e(route('rekam-medis.edit', $rm->id)); ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                                <a class="dropdown-item" href="javascript:;" data-toggle="modal" onclick="deleteDataRM('<?php echo e($rm->id); ?>')" data-target="#delete_rm"><i class="fa fa-trash-o m-r-5"></i> Hapus</a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="delete_rm" class="modal fade delete-modal" role="dialog">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <form action="" id="deleteForm_rm" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <div class="modal-body text-center">
                                            <img src="<?php echo e(asset('assets/img/sent.png')); ?>" alt="" width="50" height="46">
                                            <h3>Apakah Anda yakin ingin menghapus rekam medis ini?</h3>
                                            <div class="m-t-20">
                                                <button class="btn btn-white" data-dismiss="modal">Tidak</button>
                                                <button type="submit" class="btn btn-danger" onclick="formSubmitRM()">Hapus</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="riwayat-pembayaran">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="table table-border table-striped custom-table datatable mb-0">
                                            <thead>
                                                <tr>
                                                    <th>No. Tagihan</th>
                                                    <th>Tanggal Pembayaran</th>
                                                    <th>Tindakan</th>
                                                    <th>Total Biaya</th>
                                                    <th>Tipe Pembayaran</th>
                                                    <th>Nama Terapis</th>
                                                    <th class="text-right">Opsi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bayar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($bayar->id); ?></td>
                                                    <td><?php echo e($bayar->created_at->format('d/m/Y H:i')); ?></td>
                                                    <td><?php echo e(implode(', ', $bayar->tindakan()->get()->pluck('nama_tindakan')->toArray())); ?></td>
                                                    <td>Rp <?php echo e($bayar->total_biaya); ?></td>
                                                    <td><?php echo e($bayar->tipe_pembayaran); ?></td>
                                                    <td><?php echo e($bayar->users->name); ?></td>
                                                    <td class="text-right">
                                                        <div class="dropdown dropdown-action">
                                                            <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                                            <div class="dropdown-menu dropdown-menu-right">
                                                                <a class="dropdown-item" href="<?php echo e(route('pembayaran.edit.rm', $bayar->id)); ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                                <a class="dropdown-item" href="<?php echo e(route('invoice', $bayar->id)); ?>"><i class="fa fa-eye m-r-5"></i> View</a>
                                                                <a class="dropdown-item" href="<?php echo e(route('invoice.download', $bayar->id)); ?>"><i class="fa fa-file-pdf-o m-r-5"></i> Download</a>
                                                                <a class="dropdown-item" href="javascript:;" data-toggle="modal" onclick="deleteDataP('<?php echo e($bayar->id); ?>')" data-target="#delete_invoice"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="delete_invoice" class="modal fade delete-modal" role="dialog">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <form action="" id="deleteForm_inv" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <div class="modal-body text-center">
                                            <img src="<?php echo e(asset('assets/img/sent.png')); ?>" alt="" width="50" height="46">
                                            <h3>Apakah Anda yakin ingin menghapus riwayat pembayaran ini?</h3>
                                            <div class="m-t-20">
                                                <button class="btn btn-white" data-dismiss="modal">Tidak</button>
                                                <button type="submit" class="btn btn-danger" onclick="formSubmitP()">Hapus</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- FOOTER -->
        <?php echo $__env->make('_part.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Script modal konfirmasi hapus rekam medis -->
        <script type="text/javascript">
            function deleteDataRM(id) {
                var id = id;
                var url = '<?php echo e(route("rekam-medis.destroy", ":id")); ?>';
                url = url.replace(':id', id);
                $("#deleteForm_rm").attr('action', url);
            }

            function formSubmitRM() {
                $("#deleteForm_rm").submit();
            }
        </script>

        <!-- Script modal konfirmasi hapus riwayat pembayaran -->
        <script type="text/javascript">
            function deleteDataP(id) {
                var id = id;
                var url = '<?php echo e(route("pembayaran.destroy.rm", ":id")); ?>';
                url = url.replace(':id', id);
                $("#deleteForm_inv").attr('action', url);
            }

            function formSubmitP() {
                $("#deleteForm_inv").submit();
            }
        </script>
</body>


<!-- profile23:03-->

</html>
<?php /**PATH C:\xampp\htdocs\FisioApp\resources\views/riwayat_pasien.blade.php ENDPATH**/ ?>