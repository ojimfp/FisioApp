<!DOCTYPE html>
<html lang="en">


<!-- edit-patient24:07-->

<head>
    <?php echo $__env->make('_part.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('_part.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
    <div class="main-wrapper">
        <!-- HEADER -->
        <?php echo $__env->make('_part.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- SIDEBAR -->
        <?php echo $__env->make('_part.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END SIDEBAR -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Edit Jadwal a.n. <?php echo e($jadwal->pasien->nama); ?></h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <form action="<?php echo e(route('jadwal.update', $jadwal->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Nama Pasien<span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="nama" required value="<?php echo e($jadwal->pasien->nama); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Nama Terapis<span class="text-danger">*</span></label>
                                        <select class="select" name="nama_terapis" required autocomplete="off">
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id); ?>" <?php if($user->id == $jadwal->users_id): ?> selected <?php endif; ?>><?php echo e($user->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Tanggal Tindakan<span class="text-danger">*</span></label>
                                        <div class="cal-icon">
                                            <input type="text" name="tgl_tindakan" class="form-control datetimepicker" value="<?php echo e($jadwal->tgl_tindakan); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Jam Tindakan<span class="text-danger">*</span></label>
                                        <div class="time-icon">
                                            <input type="text" name="jam_tindakan" class="form-control" id="datetimepicker3" name="jam_tindakan" value="<?php echo e($jadwal->jam_tindakan); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Shift <span class="text-danger">*</span></label>
                                        <select class="select" name="shift" required autocomplete="off">
                                            <option <?php if($jadwal->shift == '1'): ?> selected <?php endif; ?> value='1'>Pagi</option>
                                            <option <?php if($jadwal->shift == '2'): ?> selected <?php endif; ?> value='2'>Siang</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="display-block">Status Jadwal <span class="text-danger">*</span></label>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="status" id="product_active" value="Active" <?php if($jadwal->status == 'Active'): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="product_active">
                                                Active
                                            </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="status" id="product_inactive" value="Inactive" <?php if($jadwal->status == 'Inactive'): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="product_inactive">
                                                Inactive
                                            </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="status" id="product_lainnya" value="Lainnya" <?php if($jadwal->status == 'Lainnya'): ?> checked <?php endif; ?>>
                                            <label class="form-check-label" for="product_lainnya">
                                                Lainnya
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Keterangan Status<span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="ket_status" required value="">
                                    </div>
                                </div> -->
                            </div>
                            <div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn">Simpan Perubahan Jadwal</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- FOOTER -->
    <?php echo $__env->make('_part.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>


<!-- edit-patient24:07-->

</html><?php /**PATH C:\xampp\htdocs\FisioApp\resources\views/edit_jadwal.blade.php ENDPATH**/ ?>