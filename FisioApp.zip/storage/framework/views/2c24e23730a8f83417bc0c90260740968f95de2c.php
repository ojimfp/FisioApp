<!DOCTYPE html>
<html lang="en">


<!-- patients23:17-->

<head>
    <?php echo $__env->make('_part.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('_part.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
    <div class="main-wrapper">
        <!-- HEADER -->
        <?php echo $__env->make('_part.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END HEADER -->
        <!-- SIDEBAR -->
        <?php echo $__env->make('_part.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END SIDEBAR -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-4 col-3">
                        <h4 class="page-title">List Karyawan</h4>
                    </div>
                </div>
                <div class="row filter-row">
                    <form action="<?php echo e(route('karyawan.search')); ?>" method="GET">
                        <div class="col-sm-6 col-md-3 col-lg-3 col-xl-12 col-12">
                            <div class="form-group form-focus">
                                <label class="focus-label">Cari karyawan</label>
                                <input type="text" class="form-control floating" name="keyword" autocomplete="off">
                                <div class="col-sm-6 col-md-3 col-lg-3 col-xl-1 col-12">
                                    <button class="btn btn-success submit-btn">Cari Karyawan</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-border table-striped custom-table datatable mb-0">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>ID Karyawan</th>
                                        <th>Email</th>
                                        <th>No. Telepon/HP</th>
                                        <th>Pekerjaan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e(sprintf('%04d', $user->id)); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->no_hp); ?></td>
                                        <td><?php echo e($user->pekerjaan); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- FOOTER -->
    <?php echo $__env->make('_part.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>


<!-- patients23:19-->

</html><?php /**PATH C:\xampp\htdocs\FisioApp\resources\views/karyawan.blade.php ENDPATH**/ ?>