<!DOCTYPE html>
<html lang="en">


<!-- edit-patient24:07-->

<head>
    <?php echo $__env->make('_part.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('_part.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
    <div class="main-wrapper">
        <!-- HEADER -->
        <?php echo $__env->make('_part.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- SIDEBAR -->
        <?php echo $__env->make('_part.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END SIDEBAR -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Edit Tindakan</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <?php $__currentLoopData = $tindakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(route('tindakan.update', ['tindakan' => $t->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Kode Tindakan <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="kode_tindakan" required autocomplete="off" value="<?php echo e($t->kode_tindakan); ?>">
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label>Nama Tindakan</label>
                                                <input type="text" class="form-control" name="nama_tindakan" autocomplete="off" value="<?php echo e($t->nama_tindakan); ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Harga Jual</label>
                                        <input type="form_control" class="form-control" name="harga_jual" autocomplete="off"  value="<?php echo e($t->harga_jual); ?>" onkeypress="return event.charCode >= 48 && event.charCode <=57">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Komisi Tindakan</label>
                                        <input class="form-control" type="text" name="komisi_tindakan" autocomplete="off"  value="<?php echo e($t->komisi_tindakan); ?>" onkeypress="return event.charCode >= 48 && event.charCode <=57">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Kategori Tindakan<span class="text-danger">*</span></label>
                                        <select class="select" name="kategori_tindakan" required autocomplete="off">
                                            <option <?php if($t->kategori_tindakan == 'Rendah'): ?> selected <?php endif; ?>>Rendah</option>
                                            <option <?php if($t->kategori_tindakan == 'Medium'): ?> selected <?php endif; ?>>Medium</option>
                                            <option <?php if($t->kategori_tindakan == 'Tinggi'): ?> selected <?php endif; ?>>Tinggi</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Status Member</label>
                                        <select class="select" name="status_member" required autocomplete="off">
                                            <option  <?php if($t->status_member == 'Ya'): ?> selected <?php endif; ?>>Ya</option>
                                            <option  <?php if($t->status_member == 'Tidak'): ?> selected <?php endif; ?>>Tidak</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Status Aktif</label>
                                        <select class="select" name="status_aktif" required autocomplete="off">
                                            <option  <?php if($t->status_aktif == 'Ya'): ?> selected <?php endif; ?>>Ya</option>
                                            <option  <?php if($t->status_aktif == 'Tidak'): ?> selected <?php endif; ?>>Tidak</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Keterangan</label>
                                        <input class="form-control" type="text" name="keterangan" autocomplete="off" value="<?php echo e($t->komisi_tindakan); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn">Simpan Perubahan Tindakan</button>
                            </div>
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <?php echo $__env->make('_part.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>


<!-- edit-patient24:07-->

</html>
<?php /**PATH C:\xampp\htdocs\FisioApp\resources\views/edit_tindakan.blade.php ENDPATH**/ ?>