<!DOCTYPE html>
<html lang="en">


<!-- patients23:17-->

<head>
    <?php echo $__env->make('_part.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('_part.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
    <div class="main-wrapper">
        <!-- HEADER -->
        <?php echo $__env->make('_part.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- SIDEBAR -->
        <?php echo $__env->make('_part.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END SIDEBAR -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-4 col-5">
                        <h4 class="page-title">Gaji Karyawan a.n. <?php echo e($dokter->nama_dokter); ?></h4>
                    </div>
                    <div class="col-sm-8 col-7 text-right m-b-30">
                        <a href="<?php echo e(route('gaji.create', $dokter->id)); ?>" class="btn btn-primary btn-rounded float-right"><i class="fa fa-plus"></i> Masukkan Gaji</a>
                    </div>
                </div>
                <div class="row filter-row">
                    <form action="<?php echo e(route('gaji.search')); ?>" method="GET">
                        <div class="col-sm-6 col-md-4" style="float: left;">
                            <div class="form-group form-focus">
                                <label class="focus-label">Dari</label>
                                <div class="cal-icon">
                                    <input class="form-control floating datetimepicker" type="text" name="start_date">
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-4" style="float: left;">
                            <div class="form-group form-focus">
                                <label class="focus-label">Sampai</label>
                                <div class="cal-icon">
                                    <input class="form-control floating datetimepicker" type="text" name="end_date">
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-4" style="float: left;">
                            <button class="btn btn-success submit-btn">Cari Gaji</button>
                        </div>
                    </form>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-striped custom-table datatable">
                                <thead>
                                    <tr>
                                        <th>Nama Karyawan</th>
                                        <th>ID Karyawan</th>
                                        <th>Bulan</th>
                                        <th>Hari Kerja</th>
                                        <th>Hari Masuk</th>
                                        <th>Gaji Bersih</th>
                                        <th>Gaji Total</th>
                                        <th class="text-right">Opsi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $gaji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($g->dokter->nama_dokter); ?></td>
                                        <td><?php echo e($g->dokter->id); ?></td>
                                        <td><?php echo e($g->created_at->subMonth()->locale('id_ID')->isoFormat('MMMM YYYY')); ?></td>
                                        <td><?php echo e($g->hari_kerja); ?></td>
                                        <td><?php echo e($g->hari_masuk); ?></td>
                                        <td>Rp <?php echo e(number_format($g->gaji_bersih)); ?></td>
                                        <td>Rp <?php echo e(number_format($g->total_gaji)); ?></td>
                                        <td class="text-right">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="<?php echo e(route('slip.gaji', $g->id)); ?>"><i class="fa fa-book m-r-5"></i> Slip Gaji</a>
                                                    <a class="dropdown-item" href="<?php echo e(route('gaji.edit.ind', $g->id)); ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                    <a class="dropdown-item" href="javascript:;" data-toggle="modal" onclick="deleteData('<?php echo e($g->id); ?>')" data-target="#delete_gaji"><i class="fa fa-trash-o m-r-5"></i> Hapus</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="delete_gaji" class="modal fade delete-modal" role="dialog">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <form action="" id="deleteForm" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-body text-center">
                            <img src="<?php echo e(asset('assets/img/sent.png')); ?>" alt="" width="50" height="46">
                            <h3>Apakah Anda yakin ingin menghapus gaji karyawan ini?</h3>
                            <div class="m-t-20">
                                <button class="btn btn-white" data-dismiss="modal">Tidak</button>
                                <button type="submit" class="btn btn-danger" onclick="formSubmit()">Hapus</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div> -->
    </div>
    <!-- FOOTER -->
    <?php echo $__env->make('_part.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Script modal konfirmasi hapus dokter -->
    <script type="text/javascript">
        function deleteData(id) {
            var id = id;
            var url = '<?php echo e(route("gaji.destroy.ind", ":id")); ?>';
            url = url.replace(':id', id);
            $("#deleteForm").attr('action', url);
        }

        function formSubmit() {
            $("#deleteForm").submit();
        }
    </script>
</body>


<!-- patients23:19-->

</html>
<?php /**PATH C:\xampp\htdocs\FisioApp\resources\views/gaji_individu.blade.php ENDPATH**/ ?>