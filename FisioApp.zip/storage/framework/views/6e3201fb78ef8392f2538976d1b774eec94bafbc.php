<!DOCTYPE html>
<html lang="en">


<!-- invoice-view24:07-->

<head>
    <?php echo $__env->make('_part.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
</head>

<body>
    <div class="content">
        <div class="row">
            <div class="col-sm-5 col-4">
                <h4 class="page-title" style="font-size: 20px;">Riwayat Pembayaran</h4>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-striped custom-table datatable mb-0">
                        <thead>
                            <tr>
                                <th>No. Tagihan</th>
                                <th>Tanggal Pembayaran</th>
                                <th>Nama Pasien</th>
                                <th>Tindakan</th>
                                <th>Total Biaya</th>
                                <th>Tipe Pembayaran</th>
                                <th>Nama Terapis</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bayar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($bayar->id); ?></td>
                                <td><?php echo e($bayar->created_at->format('d/m/Y H:i')); ?></td>
                                <td><?php echo e($bayar->pasien->nama); ?></td>
                                <td><?php echo e(implode(', ', $bayar->tindakan()->get()->pluck('nama_tindakan')->toArray())); ?></td>
                                <td>Rp <?php echo e(number_format($bayar->total_biaya)); ?></td>
                                <td><?php echo e($bayar->tipe_pembayaran); ?></td>
                                <td><?php echo e($bayar->users->name); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>


<!-- invoice-view24:07-->

</html>
<script src="<?php echo e(asset('assets/js/jquery-3.2.1.min.js')); ?>"></script>
<script>
    $(document).ready(function(){
        window.print();
    });
</script>

<?php /**PATH C:\xampp\htdocs\FisioApp\resources\views/pembayaran_pdf.blade.php ENDPATH**/ ?>