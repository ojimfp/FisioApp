<!DOCTYPE html>
<html lang="en">


<!-- patients23:17-->

<head>
    <?php echo $__env->make('_part.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('_part.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
    <div class="main-wrapper">
        <!-- HEADER -->
        <?php echo $__env->make('_part.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END HEADER -->
        <!-- SIDEBAR -->
        <?php echo $__env->make('_part.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END SIDEBAR -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-sm-4 col-5">
                        <h4 class="page-title">Gaji Karyawan</h4>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-users')): ?>
                    <div class="col-sm-8 col-7 text-right m-b-30">
                        <a href="<?php echo e(route('gaji.create')); ?>" class="btn btn-primary btn-rounded float-right"><i class="fa fa-plus"></i> Masukkan Gaji</a>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="row filter-row">
                    <form action="<?php echo e(route('gaji.search')); ?>" method="GET">
                        <div class="col-sm-6 col-md-3 col-lg-3 col-xl-5 col-12" style="float: left;">
                            <div class="form-group form-focus">
                                <label class="focus-label">Nama/ID Karyawan</label>
                                <input type="text" class="form-control floating" name="keyword" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3 col-lg-3 col-xl-4 col-12" style="float: left;">
                            <div class="form-group">
                                <select class="select" name="bulan_gajian">
                                    <option value="">Pilih Bulan</option>
                                    <option value="1">Januari</option>
                                    <option value="2">Februari</option>
                                    <option value="3">Maret</option>
                                    <option value="4">April</option>
                                    <option value="5">Mei</option>
                                    <option value="6">Juni</option>
                                    <option value="7">Juli</option>
                                    <option value="8">Agustus</option>
                                    <option value="9">September</option>
                                    <option value="10">Oktober</option>
                                    <option value="11">November</option>
                                    <option value="12">Desember</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3 col-lg-3 col-xl-3 col-12" style="float: left;">
                            <button class="btn btn-success submit-btn">Cari Gaji</button>
                        </div>
                    </form>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-striped custom-table datatable">
                                <thead>
                                    <tr>
                                        <th>Nama Karyawan</th>
                                        <th>ID Karyawan</th>
                                        <th>Bulan</th>
                                        <th>Hari Kerja</th>
                                        <th>Hari Masuk</th>
                                        <th>Gaji Bersih</th>
                                        <th>Gaji Total</th>
                                        <th class="text-right">Opsi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $gaji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($g->users->name); ?></td>
                                        <td><?php echo e($g->users->id); ?></td>
                                        <td><?php echo e($g->created_at->subMonth()->locale('id_ID')->isoFormat('MMMM YYYY')); ?></td>
                                        <td><?php echo e($g->hari_kerja); ?></td>
                                        <td><?php echo e($g->hari_masuk); ?></td>
                                        <td>Rp <?php echo e(number_format($g->gaji_bersih)); ?></td>
                                        <td>Rp <?php echo e(number_format($g->total_gaji)); ?></td>
                                        <td class="text-right">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="<?php echo e(route('slip.gaji', $g->id)); ?>"><i class="fa fa-book m-r-5"></i> Slip Gaji</a>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-users')): ?>
                                                    <a class="dropdown-item" href="<?php echo e(route('gaji.edit', $g->id)); ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-users')): ?>
                                                    <a class="dropdown-item" href="javascript:;" data-toggle="modal" onclick="deleteData('<?php echo e($g->id); ?>')" data-target="#delete_gaji"><i class="fa fa-trash-o m-r-5"></i> Hapus</a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="delete_gaji" class="modal fade delete-modal" role="dialog">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <form action="" id="deleteForm" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-body text-center">
                            <img src="<?php echo e(asset('assets/img/sent.png')); ?>" alt="" width="50" height="46">
                            <h3>Apakah Anda yakin ingin menghapus gaji karyawan ini?</h3>
                            <div class="m-t-20">
                                <button class="btn btn-white" data-dismiss="modal">Tidak</button>
                                <button type="submit" class="btn btn-danger" onclick="formSubmit()">Hapus</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div> -->
    </div>
    <!-- FOOTER -->
    <?php echo $__env->make('_part.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Script modal konfirmasi hapus gaji -->
    <script type="text/javascript">
        function deleteData(id) {
            var id = id;
            var url = '<?php echo e(route("gaji.destroy", ":id")); ?>';
            url = url.replace(':id', id);
            $("#deleteForm").attr('action', url);
        }

        function formSubmit() {
            $("#deleteForm").submit();
        }
    </script>
</body>


<!-- patients23:19-->

</html><?php /**PATH C:\xampp\htdocs\FisioApp\resources\views/gaji.blade.php ENDPATH**/ ?>