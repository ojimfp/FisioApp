<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?>">
<title><?php echo e($meta['title'] ?? config('app.name')); ?></title><?php /**PATH C:\xampp\htdocs\FisioApp\resources\views/_part/meta.blade.php ENDPATH**/ ?>