<!DOCTYPE html>
<html lang="en">


<!-- edit-patient24:07-->

<head>
    <?php echo $__env->make('_part.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('_part.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--[if lt IE 9]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
    <div class="main-wrapper">
        <!-- HEADER -->
        <?php echo $__env->make('_part.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- SIDEBAR -->
        <?php echo $__env->make('_part.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END SIDEBAR -->
        <div class="page-wrapper">
            <div class="content">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <h4 class="page-title">Edit Pasien</h4>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <?php $__currentLoopData = $pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(route('pasien.update', ['pasien' => $p->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Nama Lengkap <span class="text-danger">*</span></label>
                                        <input class="form-control" type="text" name="nama" value="<?php echo e($p->nama); ?>" required onkeypress="return event.charCode < 48 || event.charCode  >57">
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Alamat</label>
                                                <input type="text" class="form-control" name="alamat" value="<?php echo e($p->alamat); ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Kota <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control" name="kota" value="<?php echo e($p->kota); ?>" required autocomplete="off" onkeypress="return event.charCode < 48 || event.charCode  >57">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="display-block">Jenis Kelamin <span class="text-danger">*</span></label>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="jenis_kelamin" id="jns_pria" value="Pria"  <?php if($p->jenis_kelamin == 'Pria'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="jns_pria">
                                                        Pria
                                                    </label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="jenis_kelamin" id="jns_wanita" value="Wanita"  <?php if($p->jenis_kelamin == 'Wanita'): ?> checked <?php endif; ?>>
                                                    <label class="form-check-label" for="jns_wanita">
                                                        Wanita
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            
                                            <div class="form-group">
                                                <label>Pekerjaan</label>
                                            <input class="form-control" type="text" name="pekerjaan" autocomplete="off" value="<?php echo e($p->pekerjaan); ?>" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Tempat Lahir</label>
                                                <input type="text" class="form-control" name="tempat_lahir" autocomplete="off" required value="<?php echo e($p->tempat_lahir); ?>" onkeypress="return event.charCode < 48 || event.charCode  >57">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Tanggal Lahir <span class="text-danger">*</span></label>
                                                <div class="cal-icon">
                                                <input type="date" class="form-control" name="tgl_lahir" required autocomplete="off" value="<?php echo e($p->tgl_lahir); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>No. Telepon/HP <span class="text-danger">*</span></label>
                                            <input class="form-control" type="text" name="no_telp" required autocomplete="off" value="<?php echo e($p->no_telp); ?>" onkeypress="return event.charCode >= 48 && event.charCode <=57">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Alergi Obat</label>
                                        <textarea class="form-control" name="alergi_obat" autocomplete="off"><?php echo e($p->alergi_obat); ?></textarea>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Masalah Kulit</label>
                                        <textarea class="form-control" name="masalah_kulit" autocomplete="off"><?php echo e($p->masalah_kulit); ?></textarea>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Catatan</label>
                                        <textarea class="form-control" name="catatan" autocomplete="off"><?php echo e($p->catatan); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="m-t-20 text-center">
                                <button class="btn btn-primary submit-btn">Simpan Perubahan</button>
                            </div>
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
     <!-- FOOTER -->
     <?php echo $__env->make('_part.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>


<!-- edit-patient24:07-->

</html>
<?php /**PATH C:\xampp\htdocs\FisioApp\resources\views/edit_pasien.blade.php ENDPATH**/ ?>